<?php
interface IArCondicionado{
    public function Ligar();
    public function Desligar();
    public function AumentarTemp();
    public function DiminuirTemp();

}




?>