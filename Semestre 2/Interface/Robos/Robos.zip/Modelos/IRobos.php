<?php 
interface IRobo {
    public function Ligar();
    public function Desligar();
}





?>